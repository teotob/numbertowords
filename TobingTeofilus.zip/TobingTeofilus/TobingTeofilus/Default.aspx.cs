﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using Libs;

namespace TobingTeofilus
{
    public partial class Default : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {
            //create 5 instances
            People people1 = new People("Daniel", "Jack");
            People people2 = new People("King", "Kong");
            People people3 = new People("James", "Bond");
            People people4 = new People("Doraemon", "Doraemon");
            People people5 = new People("Thanos", "Marvel");

            //create generic collection type
            List<People> lsPeople = new List<People>();

            //populate
            lsPeople.Add(people1);
            lsPeople.Add(people2);
            lsPeople.Add(people3);
            lsPeople.Add(people4);
            lsPeople.Add(people5);

            //load datasource to repeater
            rptPeople.DataSource = lsPeople;
            rptPeople.DataBind();
        }
    }
}