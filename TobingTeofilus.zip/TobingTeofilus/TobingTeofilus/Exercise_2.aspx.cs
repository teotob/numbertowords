﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Text.RegularExpressions;

namespace TobingTeofilus
{
    public partial class Exercise_2 : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {
            
        }

        public static string NumberToWord(string input)
        {
            string result = "";
            int cents = 0;
            Int32 inputNumber = 0;
            bool finishedHundred = false;

            if (input.Contains("."))
            {
                cents = Convert.ToInt32(input.Split('.')[1]);
                inputNumber = Convert.ToInt32(input.Split('.')[0]);
            }
            else
            {
                inputNumber = Convert.ToInt32(input);
            }
            
            if (inputNumber / 1000000 > 0)//check millions
            {
                //recursively call the method
                result += NumberToWord((Convert.ToInt32(inputNumber) / 1000000).ToString()) + " million ";
                inputNumber %= 1000000;//to get the rest 
            }
            
            if (inputNumber / 1000 > 0)//check thousands
            {
                result += NumberToWord((Convert.ToInt32(inputNumber) / 1000).ToString()) + " thousand ";
                inputNumber %= 1000;
            }
            
            if (inputNumber / 100 > 0)//check hundreds
            {
                result += NumberToWord((Convert.ToInt32(inputNumber) / 100).ToString()) + " hundred ";
                inputNumber %= 100;

                finishedHundred = true;
            }

            string[] unitsWord = new string[] { "one", "two", "three", "four", "five", "six", "seven", "eight", "nine", "ten", "eleven", "twelve", "thirteen", "fourteen", "fifteen", "sixteen", "seventeen", "eighteen", "nineteen" };
            string[] tensWord = new string[] { "ten", "twenty", "thirty", "forty", "fifty", "sixty", "seventy", "eighty", "ninety" };

            //to get the rest
            if (inputNumber > 0)
            {
                if (result != "")
                {
                    result += "and ";
                }

                if (inputNumber < 20)
                {
                    result += unitsWord[Convert.ToInt16(inputNumber - 1)];
                }
                else
                {
                    result += tensWord[(Convert.ToInt16(inputNumber) / 10) - 1];

                    if (inputNumber % 10 > 0)
                    {
                        result += "-" + unitsWord[(Convert.ToInt16(inputNumber) % 10) - 1];
                    }
                }
            }

            string centsWord = "";

            //to get cents
            if (cents > 0)
            {
                if (centsWord != "")
                {
                    centsWord += "and ";
                }

                if (cents < 20)
                {
                    centsWord += unitsWord[Convert.ToInt16(cents - 1)];
                }
                else
                {
                    centsWord += tensWord[(Convert.ToInt16(cents) / 10) - 1];

                    if (cents % 10 > 0)
                    {
                        centsWord += "-" + unitsWord[(Convert.ToInt16(cents) % 10) - 1];
                    }
                }

                if (cents > 1)
                {
                    centsWord += " cents";
                }
                else
                {
                    centsWord += " cent";
                }
            }

            //to get the summary
            if (finishedHundred)
            {
                string dollar = " dollar ";

                if (inputNumber > 1)
                {
                    dollar = " dollars ";
                }

                result += dollar + "and " + centsWord;
            }

            return result.ToUpper();
        }

        protected void btnSubmit_Click(object sender, EventArgs e)
        {
            if (!string.IsNullOrEmpty(txtInput.Text))
            {
                string input = txtInput.Text;

                Regex regex = new Regex("\"(.*?)\"");
                var match = regex.Match(input);

                if(!string.IsNullOrEmpty(match.Value))
                {
                    string strNumber = match.Value.TrimStart('\"').TrimEnd('\"');

                    if (!string.IsNullOrEmpty(strNumber))
                    {
                        string words = NumberToWord(strNumber);
                        string output = input.Replace(strNumber, words);

                        lblResult.Text = output;
                    }
                }
            }
        }
    }
}